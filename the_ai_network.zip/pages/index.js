import { useEffect, useState } from "react";

export default function Home() {
  const [tools, setTools] = useState([]);

  useEffect(() => {
    async function fetchTools() {
      try {
        const res = await fetch("https://api.apis.guru/ai-tools-list.json");
        const data = await res.json();
        setTools(data.tools || []);
      } catch (err) {
        console.error("Failed to fetch tools", err);
      }
    }
    fetchTools();
  }, []);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-4xl font-bold text-center mb-6">The AI Network</h1>
      <div className="my-4 text-center bg-gray-200 p-4 rounded">
        <p>Ad Space - Paste your Google AdSense code here</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {tools.map((tool, i) => (
          <div key={i} className="shadow-lg hover:shadow-xl transition rounded-2xl p-4 bg-white">
            <h2 className="text-xl font-semibold">{tool.name}</h2>
            <p className="text-gray-600 text-sm mb-2">{tool.description}</p>
            <a
              className="inline-block text-center w-full bg-blue-600 text-white py-2 px-4 rounded"
              href={tool.affiliate_link || tool.url}
              target="_blank"
              rel="noopener noreferrer"
            >
              Visit Tool
            </a>
          </div>
        ))}
      </div>
      <div className="my-6 text-center bg-gray-200 p-4 rounded">
        <p>Ad Space - Paste your Google AdSense code here</p>
      </div>
    </div>
  );
}